import React, { Component } from 'react';

export default class Home extends Component {
  render() {
    return (
      <div>
        <p>Welcome to Workout Tracker App!</p>
      </div>
    )
  }
}